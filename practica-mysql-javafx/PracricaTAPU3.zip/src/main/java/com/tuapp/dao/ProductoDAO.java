package com.tuapp.dao;

import com.tuapp.model.Categoria;
import com.tuapp.model.Producto;
import java.util.List;

public interface ProductoDAO {

    /**
     * Consulta todas las categorías disponibles en la base de datos.
     *
     * @return Lista de objetos Categoria
     */
    List<Categoria> listarCategorias();

    /**
     * Consulta los productos pertenecientes a una categoría específica.
     *
     * @param categoriaId ID de la categoría a filtrar
     * @return Lista de objetos Producto filtrados
     */
    List<Producto> listarProductosPorCategoria(int categoriaId);
}
